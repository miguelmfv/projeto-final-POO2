package org.example.view;

public class userFrame {
    // colocar nesse frame um OLA {NOME DO USER}, botao de deslogar, botao de mostrar
    //historico de alugueis E se tiver, aluguel atual, caso nao tenha colocar um Não está
    //alugando nada
}
