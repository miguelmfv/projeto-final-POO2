package org.example.view;

public class detailedFrame {
}
