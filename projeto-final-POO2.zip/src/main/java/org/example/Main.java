package org.example;

import org.example.view.loginFrame;


public class Main {
    public static void main(String[] args) {

        loginFrame frame = new loginFrame();
        frame.setVisible(true);

    }
}